package com.dmstudio.app.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY updatedAt DESC")
    fun observeProjects(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :id")
    suspend fun getProject(id: Long): ProjectEntity?

    @Insert
    suspend fun insertProject(project: ProjectEntity): Long

    @Update
    suspend fun updateProject(project: ProjectEntity)

    @Delete
    suspend fun deleteProject(project: ProjectEntity)

    @Query("SELECT * FROM messages WHERE projectId = :projectId ORDER BY position")
    suspend fun getMessages(projectId: Long): List<MessageEntity>

    @Query("SELECT COUNT(*) FROM messages WHERE projectId = :projectId")
    fun observeMessageCount(projectId: Long): Flow<Int>

    @Insert
    suspend fun insertMessages(messages: List<MessageEntity>)
}
