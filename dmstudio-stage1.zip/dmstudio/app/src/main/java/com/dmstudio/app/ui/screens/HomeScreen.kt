package com.dmstudio.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dmstudio.app.ui.ProjectsViewModel

@Composable
fun HomeScreen(onProjects: () -> Unit, onSettings: () -> Unit, vm: ProjectsViewModel = viewModel()) {
    val projects by vm.projects.collectAsState()
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Good to see you", style = MaterialTheme.typography.headlineMedium)
        DashCard("Conversation projects", "${projects.size} saved locally", onProjects)
        DashCard("Settings", "Privacy and app info", onSettings)
        Text(
            "Overlay, accessibility matching and the message editor arrive in the next stages.",
            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun DashCard(title: String, subtitle: String, onClick: () -> Unit) {
    Card(
        onClick = onClick, Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.medium,
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(20.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
