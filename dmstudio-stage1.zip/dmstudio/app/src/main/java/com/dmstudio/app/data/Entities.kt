package com.dmstudio.app.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/** One local editing project per Instagram conversation. */
@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    /** Header title seen in Instagram (filled by the accessibility service in a later stage). */
    val conversationTitle: String = "",
    /** Fingerprint used for matching; empty until the user links the project. */
    val matchKey: String = "",
    val incomingColor: Long = 0xFFF1E7DD,
    val outgoingColor: Long = 0xFFC9747F,
    val textColor: Long = 0xFF2B2B2B,
    val fontSizeSp: Int = 15,
    val bubbleRadiusDp: Int = 18,
    val spacingDp: Int = 6,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

/** A locally edited/preview message. Never sent to Instagram. */
@Entity(
    tableName = "messages",
    foreignKeys = [ForeignKey(
        entity = ProjectEntity::class,
        parentColumns = ["id"],
        childColumns = ["projectId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("projectId")]
)
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long,
    val position: Int,
    val text: String,
    val isOutgoing: Boolean,
    val timeLabel: String = "",
    /** Original visible text this message replaces, if any. */
    val originalText: String = ""
)
