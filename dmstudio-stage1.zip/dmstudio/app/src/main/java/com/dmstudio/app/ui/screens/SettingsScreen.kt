package com.dmstudio.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = { TextButton(onClick = onBack) { Text("Back") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Privacy", style = MaterialTheme.typography.titleMedium)
            Text(
                "All projects are stored privately inside this app. Nothing is uploaded, and no Instagram " +
                    "credentials are ever requested. Local edits never change what other people see.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            HorizontalDivider()
            Text("About", style = MaterialTheme.typography.titleMedium)
            Text("DM Studio 0.1.0 (stage 1)", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
