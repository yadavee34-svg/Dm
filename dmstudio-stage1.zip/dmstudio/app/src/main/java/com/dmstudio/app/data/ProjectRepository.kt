package com.dmstudio.app.data

import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow

class ProjectRepository(private val db: AppDatabase) {
    private val dao = db.projectDao()

    val projects: Flow<List<ProjectEntity>> = dao.observeProjects()

    fun messageCount(projectId: Long): Flow<Int> = dao.observeMessageCount(projectId)

    suspend fun create(name: String): Long =
        dao.insertProject(ProjectEntity(name = name.trim().ifBlank { "Untitled project" }))

    suspend fun rename(project: ProjectEntity, newName: String) {
        dao.updateProject(
            project.copy(name = newName.trim().ifBlank { project.name }, updatedAt = System.currentTimeMillis())
        )
    }

    suspend fun delete(project: ProjectEntity) = dao.deleteProject(project)

    suspend fun duplicate(project: ProjectEntity) {
        db.withTransaction {
            val now = System.currentTimeMillis()
            // matchKey is cleared so two projects never claim the same conversation.
            val newId = dao.insertProject(
                project.copy(id = 0, name = project.name + " (copy)", matchKey = "", createdAt = now, updatedAt = now)
            )
            val copies = dao.getMessages(project.id).map { it.copy(id = 0, projectId = newId) }
            if (copies.isNotEmpty()) dao.insertMessages(copies)
        }
    }
}
