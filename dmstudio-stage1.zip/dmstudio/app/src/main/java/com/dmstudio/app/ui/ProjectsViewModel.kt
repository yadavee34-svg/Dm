package com.dmstudio.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.dmstudio.app.DmStudioApp
import com.dmstudio.app.data.ProjectEntity
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ProjectsViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = (app as DmStudioApp).repository

    val projects: StateFlow<List<ProjectEntity>> =
        repo.projects.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun create(name: String) = viewModelScope.launch { repo.create(name) }
    fun rename(p: ProjectEntity, name: String) = viewModelScope.launch { repo.rename(p, name) }
    fun duplicate(p: ProjectEntity) = viewModelScope.launch { repo.duplicate(p) }
    fun delete(p: ProjectEntity) = viewModelScope.launch { repo.delete(p) }
}
