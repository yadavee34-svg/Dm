package com.dmstudio.app

import android.app.Application
import com.dmstudio.app.data.AppDatabase
import com.dmstudio.app.data.ProjectRepository
import com.dmstudio.app.data.SettingsStore

class DmStudioApp : Application() {
    val repository by lazy { ProjectRepository(AppDatabase.get(this)) }
    val settings by lazy { SettingsStore(this) }
}
