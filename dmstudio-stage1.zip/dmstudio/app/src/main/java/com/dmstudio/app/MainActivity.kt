package com.dmstudio.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.dmstudio.app.ui.screens.HomeScreen
import com.dmstudio.app.ui.screens.ProjectsScreen
import com.dmstudio.app.ui.screens.SettingsScreen
import com.dmstudio.app.ui.screens.WelcomeScreen
import com.dmstudio.app.ui.theme.DmStudioTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val settings = (application as DmStudioApp).settings
        setContent {
            DmStudioTheme {
                val onboarded by settings.onboarded.collectAsState(initial = null)
                val scope = rememberCoroutineScope()
                val nav = rememberNavController()
                val ready = onboarded
                if (ready != null) {
                    NavHost(nav, startDestination = if (ready) "home" else "welcome") {
                        composable("welcome") {
                            WelcomeScreen(onStart = {
                                scope.launch { settings.setOnboarded() }
                                nav.navigate("home") { popUpTo("welcome") { inclusive = true } }
                            })
                        }
                        composable("home") {
                            HomeScreen(onProjects = { nav.navigate("projects") }, onSettings = { nav.navigate("settings") })
                        }
                        composable("projects") { ProjectsScreen(onBack = { nav.popBackStack() }) }
                        composable("settings") { SettingsScreen(onBack = { nav.popBackStack() }) }
                    }
                }
            }
        }
    }
}
