# DM Studio – Instagram Overlay Editor (stage 1)

Local-only visual previews of Instagram DMs. Nothing is sent to Instagram; edits are always labelled "Edited locally".

## Build the APK (no local setup needed)
1. Create a GitHub repo and push this folder.
2. Open the **Actions** tab, wait for "Build debug APK", open the run, download the `dmstudio-debug-apk` artifact.
3. Unzip, copy `app-debug.apk` to the POCO M2 Pro, and install (allow "Install unknown apps" for your file manager).

If the run fails, open the failed step and paste the error back to me.

## Local build
Open in Android Studio (Koala or newer, JDK 17) and press Run.

## Stage 1 includes
Gradle/Compose/Room setup, Cream & Rose theme, welcome, home, project CRUD (create, rename, duplicate, delete), settings, CI.
